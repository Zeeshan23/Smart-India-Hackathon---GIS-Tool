import java.util.*;
import java.io.*;
import java.lang.*;
class Transformation2
{
	public static void main(String args[]) throws IOException
    {
         String datum,text,rdatum,cdatum;
		 double major=0,minor=0,flattening=0,delx=0,dely=0,delz=0,temp;
		 System.out.println("\nEnter the name of current datum");
		 Scanner s=new Scanner(System.in);
		 datum=s.next();
		

		//abhi ke liye datum ka naam puch rhe... baad me connection hoga drop down menu se..
		 FileReader in = new FileReader("first.txt");
		 BufferedReader br=new BufferedReader(in);
		 int flag=0;
		 
		 while((text=br.readLine())!=null)
		 {
			String w[]=text.split(" ");
			//System.out.println(w[0]);
			//compare kar raha ki datum ka naam file me present hai ki nhi ,agar hai to us ki 'a' aur 'f' ki value nikal lenge...
			if(w[0].equals(datum))
			{
				System.out.println("\nDatum is present in file..");
				major=Double.parseDouble(w[1]);
				minor=Double.parseDouble(w[2]);
				temp=Double.parseDouble(w[3]);
				flattening=1/temp;
				//major, minor aur flattening height ki value nikal li 
				System.out.println(datum+" "+major+" "+minor+" "+flattening);
				flag=1;
				break;
			}		
		 }
		 
		 if(flag==0)
		 {
			 System.out.println("\nDatum not found..");
		 }
		in.close();
		
		
		
		//current datum ka region aur jisme jana hai us datum ka naam..
		System.out.println("\nEnter the name of current datum's region..");
		rdatum=s.next();
		System.out.println("\nEnter the name of datum you want to get..");
		cdatum=s.next();
		
		in = new FileReader("first.txt");
		br=new BufferedReader(in);
		double major1=0,minor1=0,flattening1=0;
		
		
		//jisme jana hai uska minor , major aur flattening ki value nikal rha 
		while((text=br.readLine())!=null)
		 {
			String w[]=text.split(" ");
			//System.out.println(w[0]);
			//compare kar raha ki datum ka naam file me present hai ki nhi ,agar hai to us ki 'a' aur 'f' ki value nikal lenge...
			if(w[0].equals(cdatum))
			{
				System.out.println("\nDatum is present in file..");
				major1=Double.parseDouble(w[1]);
				minor1=Double.parseDouble(w[2]);
				temp=Double.parseDouble(w[3]);
				flattening1=1/temp;
				//major, minor aur flattening height ki value nikal li 
				System.out.println(cdatum+" "+major1+" "+minor1+" "+flattening1);
				flag=1;
				break;
			}		
		 }
		 if(flag==0)
		 {
			 System.out.println("\nDatum not found..");
		 }
		in.close();
		
		
		
		//claculating change in major and flattening
		double delmajor=major1-major;
		double delflattening=flattening1-flattening;
		
		//PEHLI File band kar di
		// ab Dusri FILE kholunga
		in = new FileReader("second.txt");
		br=new BufferedReader(in);
		
		flag=0;
		
		while((text=br.readLine())!=null)
		 {
			String w[]=text.split(" ");
			//System.out.println(w[0]);
			//compare kar raha ki datum ka naam file me present hai ki nhi ,agar hai to us ki 'a' aur 'f' ki value nikal lenge...
			if(w[0].equals(datum) && w[1].equals(rdatum) && w[2].equals(cdatum))
			{
				System.out.println("\nDatum is present in file..");
				delx=Double.parseDouble(w[3]);
				dely=Double.parseDouble(w[4]);
				delz=Double.parseDouble(w[5]);
				//delx, dely aur delz ki value nikal li 
				System.out.println(datum+" "+rdatum+" "+cdatum+" "+delx+" "+dely+" "+delz);
				flag=1;
				break;
			}		
		 }
		 if(flag==0)
		 {
			 System.out.println("\nDatum not found..");
		 }
		
		in.close();
		
		//Current DATUM KA LATITUDE, LONGITIDE AUR height le rha
		double lat,longg,height;
		System.out.println("\nEnter the name of latitude of current datum");
		lat=s.nextDouble();
		System.out.println("\nEnter the name of longitude of current datum");
		longg=s.nextDouble();
		System.out.println("\nEnter the name of height of current datum");
		height=s.nextDouble();
		
		
		
		double esquare,rad,rlat,rlongg,prad;
		//eccentricity ka square 
		esquare=flattening*(2-flattening);
		System.out.println("\nEccentricity square : "+esquare);
		//longitude and latitude ko pehle radiun me calculate then sine ya cos lagega
		rlat=Math.toRadians(lat);
		rlongg=Math.toRadians(longg);
		
		
		// square of sin of lat
		double sqSinLat=Math.pow(Math.sin(rlat),2);
		System.out.println("\nSIN^2 PHIE : "+sqSinLat);
		
		//radius of curvature of the ellipsoid in prime vertical plane
		rad=major/Math.sqrt((1-esquare*sqSinLat));
		System.out.println("\nv : "+rad);
		
		//radius of curvature of the ellipsoid in meridian plane
		prad=major*(1-esquare)/Math.pow((1-esquare*sqSinLat),1.5);
		System.out.println("\nrow : "+prad);
		
		//calculating some intermediate values.
		double coslat,sinlat,sinlongg,coslongg;
		coslat=Math.cos(rlat);
		sinlat=Math.sin(rlat);
		coslongg=Math.cos(rlongg);
		sinlongg=Math.sin(rlongg);
		
		
		//now calculating delta lat,delta longg, delta height
		double dellat,dellongg,delheight;
		
		//del of latitude
		dellat=((-delx*sinlat*coslongg-dely*sinlat*sinlongg+delz*coslat+((rad*esquare*sinlat*coslat*delmajor)/major)+sinlat*coslat*((prad/(1-flattening))+rad*(1-flattening))*delflattening)/(prad+height));
		System.out.println("\nDELLAT IN RADIANS: "+dellat);
		System.out.println("\nDELLAT in DEGREES SECOND : "+Math.toDegrees(dellat)*60*60);
		
		//del of longitude
		dellongg=(-delx*sinlongg+dely*coslongg)/((rad+height)*coslat);
		System.out.println("\ndellongg in radians: "+dellongg);
		System.out.println("\nDELLONGG in DEGREES SECONDS: "+Math.toDegrees(dellongg)*60*60);
		
		//del of height
		delheight=delx*coslat*coslongg+dely*coslat*sinlongg+delz*sinlat-((major*delmajor)/rad)+rad*(1-flattening)*sqSinLat*delflattening;
		System.out.println("\ndelheight : "+delheight);
		//printing datum its region along with latitude,longitude and height
		System.out.println(datum+" "+rdatum+" "+" "+lat+" "+longg+" "+height);
		
		double nlat=lat+dellat;
		double nlongg=longg+dellongg;
		double nheight=height+delheight;
		
		//printing new datum its region along with latitude,longitude and height
		System.out.println(cdatum+" "+rdatum+" "+" "+nlat+" "+nlongg+" "+nheight);
		//System.out.println("\nDELMAJOR: "+delmajor);
		//double check=((rad*esquare*sinlat*coslat*delmajor)/major);
		//System.out.println("\nDCHECK : "+check);
    }
}
