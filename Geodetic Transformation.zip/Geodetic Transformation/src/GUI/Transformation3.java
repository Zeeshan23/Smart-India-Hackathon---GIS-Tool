import java.util.*;
import java.io.*;
import java.lang.*;
class Basic
{
	public static double eccentricitysquare(double flattening)
	{
		return flattening*(2-flattening);
	}
	public static double sincosfunc(double value,int val)
	{
		//longitude and latitude ko pehle radian me calculate then sine ya cos lagega
		if(val==1)
		{
			return(Math.sin(Math.toRadians(value)));
		}
		else
		{
			return(Math.cos(Math.toRadians(value)));
		}
	}
	public static double dellatitude(double delx,double dely,double delz,double sinlat,double sinlongg,double coslat,double coslongg,double height,double flattening,double delflattening,double delmajor,double major)
	{
		//method that return delta of latitude
		double esquare,rad,prad;
		//eccentricity ka square 
		esquare=eccentricitysquare(flattening);
		// square of sin of lat
		double sqSinLat=Math.pow(sinlat,2);
		//radius of curvature of the ellipsoid in prime vertical plane
		rad=major/Math.sqrt((1-esquare*sqSinLat));
		
		//radius of curvature of the ellipsoid in meridian plane
		prad=major*(1-esquare)/Math.pow((1-esquare*sqSinLat),1.5);
		return(((-delx*sinlat*coslongg-dely*sinlat*sinlongg+delz*coslat+((rad*esquare*sinlat*coslat*delmajor)/major)+sinlat*coslat*((prad/(1-flattening))+rad*(1-flattening))*delflattening)/(prad+height)));
		
	}
	public static double dellongitude(double delx,double dely,double sinlat,double sinlongg,double coslat,double coslongg,double height,double major,double flattening)
	{
		//method that return delta of latitude
		double esquare,rad;
		//eccentricity ka square 
		esquare=eccentricitysquare(flattening);
		// square of sin of lat
		double sqSinLat=Math.pow(sinlat,2);
		//radius of curvature of the ellipsoid in prime vertical plane
		rad=major/Math.sqrt((1-esquare*sqSinLat));
		return((-delx*sinlongg+dely*coslongg)/((rad+height)*coslat));
	}
	public static double del_height(double delx,double dely,double delz,double sinlat,double sinlongg,double coslat,double coslongg,double major,double flattening,double delflattening,double delmajor)
	{
		//method that return delta of latitude
		double esquare,rad;
		//eccentricity ka square 
		esquare=eccentricitysquare(flattening);
		// square of sin of lat
		double sqSinLat=Math.pow(sinlat,2);
		//radius of curvature of the ellipsoid in prime vertical plane
		rad=major/Math.sqrt((1-esquare*sqSinLat));
		return(delx*coslat*coslongg+dely*coslat*sinlongg+delz*sinlat-((major*delmajor)/rad)+rad*(1-flattening)*sqSinLat*delflattening);
	}
	public static void main(String args[]) throws IOException
    {
                 String datum,text,rdatum,cdatum;
		 double major=0,minor=0,flattening=0,delx=0,dely=0,delz=0,temp;
		 double major1=0,minor1=0,flattening1=0;
		 
		 //Current datum ka naam,region aur jisme jana hai us datum ka naam..
		 System.out.println("\nEnter the name of current datum");
		 Scanner s=new Scanner(System.in);
		 datum=s.next();
		 System.out.println("\nEnter the name of current datum's region..");
		 rdatum=s.next();
		 System.out.println("\nEnter the name of datum you want to get..");
		 cdatum=s.next();

		//abhi ke liye datum ka naam puch rhe... baad me connection hoga drop down menu se..
		 FileReader in = new FileReader("first.txt");
		 BufferedReader br=new BufferedReader(in);
		 int flag1=0,flag2=0;
		 
		 while((text=br.readLine())!=null)
		 {
			String w[]=text.split(" ");
			//System.out.println(w[0]);
			//compare kar raha ki datum ka naam file me present hai ki nhi ,agar hai to us ki 'a' aur 'f' ki value nikal lenge...
			if(flag1==1 && flag2==1)
				break;
			
			if(w[0].equals(datum))
			{
				System.out.println("\nCurrent Datum is present in file..");
				major=Double.parseDouble(w[1]);
				minor=Double.parseDouble(w[2]);
				temp=Double.parseDouble(w[3]);
				flattening=1/temp;
				//major, minor aur flattening height ki value nikal li 
				System.out.println(datum+" "+major+" "+minor+" "+flattening);
				flag1=1;
			}	
			else if(w[0].equals(cdatum))
			{
				System.out.println("\nConverted Datum is present in file..");
				major1=Double.parseDouble(w[1]);
				minor1=Double.parseDouble(w[2]);
				temp=Double.parseDouble(w[3]);
				flattening1=1/temp;
				//major, minor aur flattening height ki value nikal li 
				System.out.println(cdatum+" "+major1+" "+minor1+" "+flattening1);
				flag2=1;
			}		
		 }
		 
		 if(flag1==0)
		 {
			 System.out.println("\nCurrent Datum not found..");
		 }
		 if(flag2==0)
		 {
			 System.out.println("\nConverted Datum not found..");
		 }
		in.close();
		
		
		//claculating change in major and flattening
		double delmajor=major1-major;
		double delflattening=flattening1-flattening;
		
		//PEHLI File band kar di
		// ab Dusri FILE kholunga
		in = new FileReader("second.txt");
		br=new BufferedReader(in);
		
		flag1=0;
		
		while((text=br.readLine())!=null)
		 {
			String w[]=text.split(" ");
			//System.out.println(w[0]);
			//compare kar raha ki datum ka naam file me present hai ki nhi ,agar hai to us ki 'a' aur 'f' ki value nikal lenge...
			if(w[0].equals(datum) && w[1].equals(rdatum) && w[2].equals(cdatum))
			{
				System.out.println("\nFull Datum Transformation details is present in file..");
				delx=Double.parseDouble(w[3]);
				dely=Double.parseDouble(w[4]);
				delz=Double.parseDouble(w[5]);
				//delx, dely aur delz ki value nikal li 
				System.out.println(datum+" "+rdatum+" "+cdatum+" "+delx+" "+dely+" "+delz);
				flag1=1;
				break;
			}		
		 }
		 if(flag1==0)
		 {
			 System.out.println("\nFull Datum Transformation details not found..");
		 }
		
		in.close();
		
		//Current DATUM KA LATITUDE, LONGITIDE AUR height le rha
		double lat,longg,height;
		System.out.println("\nEnter the name of latitude of current datum");
		lat=s.nextDouble();
		System.out.println("\nEnter the name of longitude of current datum");
		longg=s.nextDouble();
		System.out.println("\nEnter the name of height of current datum");
		height=s.nextDouble();
		
		
		//calculating some intermediate values.
		double coslat,sinlat,sinlongg,coslongg;
		//SEND 1 for SIN and 2 for COS..
		coslat=sincosfunc(lat,2);
		sinlat=sincosfunc(lat,1);
		coslongg=sincosfunc(longg,2);
		sinlongg=sincosfunc(longg,1);
		
		//now calculating delta lat,delta longg, delta height
		double dellat,dellongg,delheight;
		
		//del of latitude
		dellat=dellatitude(delx,dely,delz,sinlat,sinlongg,coslat,coslongg,height,flattening,delflattening,delmajor,major);
		System.out.println("\nDELLAT IN RADIANS: "+dellat);
		System.out.println("\nDELLAT in DEGREES SECOND : "+Math.toDegrees(dellat)*60*60);
		
		//del of longitude
		dellongg=dellongitude(delx,dely,sinlat,sinlongg,coslat,coslongg,height,major,flattening);
		System.out.println("\ndellongg in radians: "+dellongg);
		System.out.println("\nDELLONGG in DEGREES SECONDS: "+Math.toDegrees(dellongg)*60*60);
		
		//del of height
		delheight=del_height(delx,dely,delz,sinlat,sinlongg,coslat,coslongg,major,flattening,delflattening,delmajor);
		System.out.println("\ndelheight : "+delheight);
		
		//printing current datum, its region along with latitude,longitude and height
		System.out.println(datum+" "+rdatum+" "+" "+lat+" "+longg+" "+height);
		
		double nlat=lat+dellat;
		double nlongg=longg+dellongg;
		double nheight=height+delheight;
		
		//printing new datum its region along with latitude,longitude and height
		System.out.println(cdatum+" "+rdatum+" "+" "+nlat+" "+nlongg+" "+nheight);
		
    }
}
