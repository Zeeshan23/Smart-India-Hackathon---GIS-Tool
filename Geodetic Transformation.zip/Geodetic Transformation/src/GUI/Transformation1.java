package GUI;

import java.io.*;
import java.io.IOException;
import java.util.*;

public class Transformation1
{
    
       static double a,b,f;
    
        public double Longitude()
        {
            InputStream f1 = Transformation1.class.getResourceAsStream("abc.txt");
            
            if(f1==null)
            {
               System.out.println("abc.txt" +" "+ "does not exists");
               return 0.0;
            }
            
            //if(!(f1.isFile() && f1.canRead())){
            //    System.out.println(f1.getName() + "cannot be read from.");
            //    return 0.0;
                
            //}
            
            try
            {
                BufferedReader br = new BufferedReader(new InputStreamReader(f1));
                
                String strLine;
                
                while ((strLine = br.readLine()) != null)   
                {
                    String[] tokens = strLine.split(" ");
                    
                    a = Double.parseDouble(tokens[1]);
                    b =  Double.parseDouble(tokens[2]);
                    f = Double.parseDouble(tokens[3]);
                   
                }
                
            }
            
            catch(IOException e)
            {
                e.printStackTrace();
            }
           
            return(a);            
        }    
}

